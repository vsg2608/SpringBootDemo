package com.mkj.boot.BootDemo1;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	// use to define users and roles
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		System.out.println(" --- @Configuration auth builder");
		
		auth.inMemoryAuthentication().
		withUser("user").password("{noop}user").roles("user").
		and().
		withUser("admin").password("{noop}admin").roles("user","admin");
	}
	
	// use to define the access to resource
	@Override
	protected void configure(HttpSecurity http) throws Exception {
			
		System.out.println(" --- @Configuration http security");
		http.httpBasic().and().authorizeRequests().
		antMatchers("/student/**").hasRole("user").
		antMatchers("/**").hasRole("admin").
		and().
		csrf().disable().headers().frameOptions().disable();
	}

}


