package com.mkj.boot.BootDemo1;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FirstRestController {

	List<Student> list = new ArrayList<>();
	
	public FirstRestController()
	{
		list.add(new Student(1, "Albaar", 150));
		list.add(new Student(2, "Hutami", 650));
		list.add(new Student(3, "AlSaud", 350));
		
		System.out.println("----->> First Rest Controller Constructor ...");
	}
	
	@GetMapping("/")
	public String firstMapping()
	{
			return "hello from rest @"+LocalDateTime.now();
	}
	
	
	
	@GetMapping("/student/{id}")
	public Student getStudentById(@PathVariable int id)
	{
		System.out.println(" ---->> inside getStudentById(@PathVariable int id) ");
			Student temp = null;
			for(Student s:list)
			{
				if(s.getId() == id){
					temp = s;
					break;
				}
				
			}
			
			return temp;
	}
	
	@GetMapping("/student/{name}/marks")
	public int getStudentByName(@PathVariable String name)
	{
		
		System.out.println("------->> inside getStudentByName(@PathVariable) ");
			int marks = 0;
			for(Student s:list)
			{
				if(s.getName().equals(name)){
					marks = s.getMarks();
					break;
				}
				
			}
			
			return marks;
	}
	
	
	@PostMapping("/system/student")
	public boolean addStudent(@RequestBody Student student)
	{
		System.out.println("-------->>  inside addStudent ");
		return list.add(student);
	}
	
	
}
